from datetime import date

print("Enter intended start date details: ")
year = int(input('Year: '))
month = int(input('Month: '))
day = int(input('Day: '))
startdate = date(year, month, day)

print("Enter intended enddate details: ")
year = int(input('Year: '))
month = int(input('Month: '))
day = int(input('Day: '))
enddate = date(year, month, day)
numberofdays = enddate - startdate

print (numstudydays)
